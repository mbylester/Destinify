<?php
// Kopyahin bilang api/f11_config.php at punan. Ilagay sa .gitignore!
return [
  'db' => ['host'=>'127.0.0.1','name'=>'destinify_app','user'=>'root','pass'=>''],
  'site_url' => 'http://localhost/Destinify/',   // gamitin ang totoong domain kapag live
  'smtp' => [
    'host'=>'smtp.gmail.com','port'=>587,'secure'=>'tls',   // 465 + 'ssl' ay pwede rin
    'user'=>'benlesterh@gmail.com',
    'pass'=>'xjtx vzcs kxpp xuzt',                          // Gmail App Password
    'from_name'=>'Destinify',
  ],
  'admin_email' => 'benlesterh@gmail.com',     // dito mapupunta ang feedback
  // I-adjust ayon sa totoong columns sa phpMyAdmin:
  'find_user_sql'    => "SELECT u.id, u.username, p.email FROM users u JOIN user_profiles p ON p.user_id=u.id WHERE p.email=? LIMIT 1",
  'set_password_sql' => "UPDATE users SET password_hash=? WHERE id=?",
];
