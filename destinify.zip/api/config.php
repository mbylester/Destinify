<?php
// Copy this file to config.php and edit the values. config.php is ignored by git, so your password stays private.
// Defaults below match a fresh XAMPP install (user "root", empty password).
return [
    'db_host'      => '127.0.0.1',
    'db_port'      => 3306,
    'db_name'      => 'destinify_app',
    'db_user'      => 'root',
    'db_pass'      => '',
    'session_name' => 'destinify_sid',
];
